/**
 * @file sop.c
 * @brief state of power module
 * @note this is a placeholder, not finished yet
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */

